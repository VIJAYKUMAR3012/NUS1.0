<?php

include "../dbconn.php";

$username = $_POST["username"];
$emailid = $_POST["emailid"];
$role = $_POST["role"];
$r = $_POST["parentcompany"];
$e = $_POST["bussinessunit"];
$password = $_POST["password"];
$hash = password_hash($password,  
          PASSWORD_DEFAULT); 


$sqlValues = '';
foreach($e as $bu) {
    $sqlValues .= "$bu, " ;
}

$multiselect = $sqlValues;
echo $multiselect;
// echo $sql;
if ($r =='') {
    $username = $_POST["username"];
    $emailid = $_POST["emailid"];
    $role = $_POST["role"];
    $password = $_POST["password"];
    $hash = password_hash($password,  
          PASSWORD_DEFAULT); 

    $sql = "INSERT INTO nususerdata(username, emailid, role, accountstatus,password)
            VALUES('$username', '$emailid', '$role', '0', '$hash' )";
}

elseif ($r !='') {
    $username = $_POST["username"];
    $emailid = $_POST["emailid"];
    $role = $_POST["role"];
    $password = $_POST["password"];
    $hash = password_hash($password,  
          PASSWORD_DEFAULT);     
    $r = $_POST["parentcompany"];

    //Insert Query of SQL
    $sql = "INSERT INTO clientuser(username, emailid, role, accountstatus, parentcompany, password)
            VALUES('$username', '$emailid', '$role', '0','$r', '$hash')";
}

elseif ($e !='') {

    
    $username = $_POST["username"];
    $emailid = $_POST["emailid"];
    $role = $_POST["role"];
    $r = $_POST["parentcompany"];
    $e = $_POST["bussinessunit"];
    $password = $_POST["password"];
    $hash = password_hash($pwd,  
            PASSWORD_DEFAULT); 
    


        $sqlValues = '';
        foreach($e as $bu) {
            $sqlValues .= "$bu, " ;
        }

    $multiselect = $sqlValues;
    echo $multiselect;
    // echo $sql;
    $sql = "INSERT INTO clientuser(username, emailid, role, accountstatus, parentcompany, password, businessunit)
        VALUES('$username', '$emailid', '$role', 'Invited','$r', '$hash', '$multiselect')";

    
    }

$query=mysqli_query($conn,$sql);
echo $role;

echo "<script>
             alert(' Mail sent succesfully'); 
             window.history.go(-2);
     </script>";


     require 'includes/PHPMailer.php';
     require 'includes/SMTP.php';
     require 'includes/Exception.php';
     
     use PHPMailer\PHPMailer\PHPMailer;
     use PHPMailer\PHPMailer\SMTP;
     use PHPMailer\PHPMailer\Exception;
     
     $mail = new PHPMailer();
     
     $mail->isSMTP();
     
     $mail->Host = "smtp.gmail.com";
     $mail->SMTPAuth = "true";
     $mail->SMTPSecure = "tls";
     $mail->Port = "587";
     $mail->Username = "vkt973012@gmail.com";
     $mail->Password = "xdpirmapeycfoylo";
     $mail->Subject = "NUS user Created";
     $mail->setFrom("vkt973012@gmail.com", 'vijaygowda');
     $mail->Body = "http://localhost/nusconsultinggroup_w/submit.php";
    
     $mail->addAddress('Vijayakumar.kt@qualesce.com');
     
     if($mail->Send()) {
         echo "Email Sent!";
     } else {
         echo "Mail not sent!";
     }
     
     $mail->smtpClose();
     
     


?>