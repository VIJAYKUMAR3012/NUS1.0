<?php
    include('security.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <s src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   
    <title>NUS FRS System | Add Company</title>
    <link rel="icon" href="img/social-square-n-blue.png" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <style>
      
.tabs {
  font-family: "Poppins", sans-serif;
  display: flex;
  align-items: center;
  flex-direction: column;
  width: 100%;
  min-height: 100vh;
}
.sidebar {
  /* display: flex; */
  /* align-items: center; */
  /* justify-content: center; */
  width: 100%;
  /* margin: 30px 0 0 600px; */
}

.sidebardata {
  width: 100%;
  margin: 30px 0 0 600px;
}
.tab-btn {
  background-color: #f9fbfd;
  border: none;
  border-bottom: 1px solid #6e84a3;
  color: #6e84a3;
  cursor: pointer;
  padding: 10px 0;
  margin: 10px 0;
  outline: none;
  width: 10%;
  position: absolute;
  left: 35%;
  top: 8%;
}
.tab-btn-active {
  border-bottom: 2px solid #12263f;
  color: #12263f;
  font-weight: bold;
  position: absolute;
  left: 22%;
  top: 8%;
}
/* tabs content */
.content {
  width: 100%;
}
.tab-content {
  display: flex;
  flex-direction: column;
  /* align-items: center; */
  /* justify-content: center; */
  /* text-align: center; */
  width: 100%;
  /* height: 100vh; */
  position: absolute;
  top: 7rem;
  display: none;
}
.tab-content-active {
  display: block;
}
 .tab-content img {
  width: 350px;
} 

    </style>
    </head>
<body>
    <div class="main">
        <div class="menu">

            <?php
                include('sidebar.php');
            ?>
        </div>
    <div>
    <!-- <div class="contentMove"></div> -->
        <!-- <h1> Add Company Page</h1>
        <p>Continue to add from here</p> -->

        <a href="addparent.php" class="addParentCompany">Parent Company</a>
        <a href="addclient.php" class="addClientCompany">Client Company</a>


        <div class="tabs">
          <div class="sidebar">
      <!-- tabs buttons  -->
      <button class="tab-btn tab-btn-active" data-for-tab="1">Parent Comapny</button>
      <button class="tab-btn" data-for-tab="2">Client Company</button>
      <!-- <button class="tab-btn" data-for-tab="3">a Company</button> -->
    </div>
      <!-- tabs content  -->
      <!-- <div class="content"> -->
          <div class="tab-content tab-content-active" data-tab="1">
              <?php
                include('listaddparentcompany.php');
              ?>
           </div>
            <div class="tab-content" data-tab="2">
            <?php
                include('listclientcompany.php');
              ?>
            </div>
            </div>

<?php
    include('hoverinclude/hovercompany.php');
?>
       <!-- </div> -->
 </div>

 <script>
  function setupTabs() {
  document.querySelectorAll(".tab-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const sidebar = button.parentElement;
      const tabs = sidebar.parentElement;
      const tabNumber = button.dataset.forTab;
      const tabActivate = tabs.querySelector(
        `.tab-content[data-tab="${tabNumber}"]`
      );

      sidebar.querySelectorAll(".tab-btn").forEach((button) => {
        button.classList.remove("tab-btn-active");
      });
      tabs.querySelectorAll(".tab-content").forEach((tab) => {
        tab.classList.remove("tab-content-active");
      });
      button.classList.add("tab-btn-active");
      tabActivate.classList.add("tab-content-active");
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setupTabs();
});

 </scrip>
  

</body>
</html>